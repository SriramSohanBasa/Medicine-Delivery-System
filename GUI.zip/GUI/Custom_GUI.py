import customtkinter as ctk
import tkinter as tk
from tkinter import ttk, messagebox
import pyodbc
import os
import webbrowser

# Database connection parameters
server = 'ROG'
database = 'PharmacyDB'
driver = '{SQL Server}'

# Establish a database connection
conn_str = f'DRIVER={driver};SERVER={server};DATABASE={database};'
conn = pyodbc.connect(conn_str)
cursor = conn.cursor()
ctk.set_appearance_mode("dark-blue")
class CustomApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Prescription Management System")
        self.root.geometry("800x600")
        self.views_frame = ctk.CTkFrame(self.root)

        # Apply a custom style to the Treeview
        style = ttk.Style()
        style.configure("Treeview.Heading", background="lightblue", font=("Arial", 10, "bold"))
        style.configure("Treeview", font=("Arial", 10))
        style = ttk.Style()

# This is where you can experiment with different theme names 
# 'clam', 'alt', 'default', 'classic' to find one that is to your liking.

        # Intro page
        self.intro_frame = ctk.CTkFrame(self.root)
        self.intro_frame.pack(fill="both", expand=True)

        intro_label = ctk.CTkLabel(self.intro_frame, text="Prescription Management System", font=("Comic Sans MS", 24,"bold"))
        intro_label.pack(pady=20)

        open_button = ctk.CTkButton(self.intro_frame, text="Open Application", command=self.show_options)
        open_button.pack(pady=10) 

        # Options page
        self.options_frame = ctk.CTkFrame(self.root)
 
        button_names = ["Insert", "Update", "Delete", "Read", "Views","Visualization"]
        button_commands = [self.show_main_page, self.update_patient, self.delete_patient, self.show_read_page, self.show_views_page,self.show_visualization]
        button_colors = ["#D1B43F", "#D1B43F", "#D1B43F", "#D1B43F", "#D1B43F","#D1B43F"]
        button_text_color = "black"
        button_width=150
        button_font = ("Comic Sans MS", 10, "bold")
        for name, command, color in zip(button_names, button_commands, button_colors):
            button = ctk.CTkButton(self.options_frame, text=name, command=command, fg_color=color,text_color=button_text_color,font=button_font)
            button.pack(pady=10, padx=20, fill="x")

        # Main application page
        self.main_frame = ctk.CTkFrame(self.root)

        # View all patients page
        self.view_all_frame = ctk.CTkFrame(self.root)

        back_button_view_all = ctk.CTkButton(self.view_all_frame, text="Back", command=self.show_options)
        back_button_view_all.pack(pady=10, anchor='nw')

        self.patients_table = ttk.Treeview(self.view_all_frame, columns=("First Name", "Last Name", "Email", "Contact Number"), show="headings")
        self.patients_table.heading("First Name", text="First Name")
        self.patients_table.heading("Last Name", text="Last Name")
        self.patients_table.heading("Email", text="Email")
        self.patients_table.heading("Contact Number", text="Contact Number")
        self.patients_table.pack(fill="both", expand=True)

        # Read page
        self.read_frame = ctk.CTkFrame(self.root)

        back_button_read = ctk.CTkButton(self.read_frame, text="Back", command=self.show_options)
        back_button_read.pack(pady=10, anchor='nw')

        self.table_dropdown = ttk.Combobox(self.read_frame)
        self.table_dropdown.pack(pady=10)

        show_table_button = ctk.CTkButton(self.read_frame, text="Show Table", command=self.show_table)
        show_table_button.pack(pady=10)

        self.table_content = ttk.Treeview(self.read_frame)
        self.table_content.pack(fill="both", expand=True)

        # Get table names for the dropdown
        cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_type = 'BASE TABLE' AND table_schema = 'dbo'")
        self.table_dropdown['values'] = [row[0] for row in cursor.fetchall()]

        # Views page
        self.views_frame = ctk.CTkFrame(self.root)
    def show_visualization(self):
    # Open the PBIX file using the default application (Power BI Desktop)
    
        os.startfile(r"C:\Users\srira\Downloads\DMDD Visualisation\DMDD Visualisation\DMDD Group 14.pbix")

    def show_options(self):
        self.intro_frame.pack_forget()
        self.main_frame.pack_forget()
        self.view_all_frame.pack_forget()
        self.read_frame.pack_forget()
        self.views_frame.pack_forget()
        self.options_frame.pack(fill="both", expand=True)

    def show_main_page(self):
        self.options_frame.pack_forget()
        self.main_frame.pack(fill="both", expand=True)

        # Clear previous widgets in the main frame
        for widget in self.main_frame.winfo_children():
            widget.destroy()

        header_label = ctk.CTkLabel(self.main_frame, text="Insert Data", font=("Arial", 24))
        header_label.pack(pady=20)

        # Table selection dropdown
        self.table_selection = ttk.Combobox(self.main_frame, state="readonly")
        self.table_selection.pack(pady=10)
        self.table_selection.bind("<<ComboboxSelected>>", self.generate_form_fields)

        # Fetch table names for the dropdown
        cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_type = 'BASE TABLE' AND table_schema = 'dbo'")
        self.table_selection['values'] = [row[0] for row in cursor.fetchall()]

        # Placeholder for form fields
        self.form_frame = ctk.CTkFrame(self.main_frame)
        self.form_frame.pack(pady=10)

        back_button_main = ctk.CTkButton(self.main_frame, text="Back", command=self.show_options)
        back_button_main.pack(pady=10)
    def show_views_page(self):
        self.options_frame.pack_forget()
        self.views_frame.pack(fill="both", expand=True)

        # Clear previous widgets in the views frame
        for widget in self.views_frame.winfo_children():
            widget.destroy()

        header_label = ctk.CTkLabel(self.views_frame, text="View Data", font=("Arial", 24))
        header_label.pack(pady=20)

        # View selection dropdown
        self.view_selection = ttk.Combobox(self.views_frame, state="readonly")
        self.view_selection.pack(pady=10)
        self.view_selection.bind("<<ComboboxSelected>>", self.load_view)

        # Fetch view names for the dropdown
        cursor.execute("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_SCHEMA = 'dbo'")
        self.view_selection['values'] = [row[0] for row in cursor.fetchall()]

        # Placeholder for view data
        self.view_data_frame = ctk.CTkFrame(self.views_frame)
        self.view_data_frame.pack(fill="both", expand=True, pady=10)

        back_button_views = ctk.CTkButton(self.views_frame, text="Back", command=self.show_options)
        back_button_views.pack(pady=10)

    def load_view(self, event):
        view_name = self.view_selection.get()
        if view_name:
            for widget in self.view_data_frame.winfo_children():
                widget.destroy()

            cursor.execute(f"SELECT * FROM {view_name}")
            columns = [desc[0] for desc in cursor.description]
            view_data_table = ttk.Treeview(self.view_data_frame, columns=columns, show="headings")

            for col in columns:
                view_data_table.heading(col, text=col)

            for row in cursor:
                view_data_table.insert('', tk.END, values=row)

            view_data_table.pack(fill="both", expand=True)

            view_name_label = ctk.CTkLabel(self.views_frame, text=view_name, font=("Arial", 16, "bold"))
            view_name_label.pack(pady=5, before=view_data_table)
    def generate_form_fields(self, event):
        # Clear previous form fields
        for widget in self.form_frame.winfo_children():
            widget.destroy()

        table_name = self.table_selection.get()
        cursor.execute(f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{table_name}'")
        columns = [row[0] for row in cursor.fetchall()]

        self.entry_fields = {}
        for column in columns:
            field_frame = ctk.CTkFrame(self.form_frame)
            field_frame.pack(fill="x", pady=2)

            label = ctk.CTkLabel(field_frame, text=column)
            label.pack(side="left", padx=5)
            entry = ctk.CTkEntry(field_frame, width=200)
            entry.pack(side="right", padx=5)
            self.entry_fields[column] = entry

        insert_button = ctk.CTkButton(self.form_frame, text="Insert into this table", command=self.insert_data)
        insert_button.pack(pady=10)

    def insert_data(self):
        table_name = self.table_selection.get()
        columns = ", ".join(self.entry_fields.keys())
        values = ", ".join([f"'{entry.get()}'" for entry in self.entry_fields.values()])
        sql = f"INSERT INTO {table_name} ({columns}) VALUES ({values})"
        try:
            cursor.execute(sql)
            conn.commit()
            messagebox.showinfo("Success", "Data inserted successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Could not insert data into the database. {e}")

    def view_all_patients(self):
        self.options_frame.pack_forget()
        self.view_all_frame.pack(fill="both", expand=True)
        self.update_patients_table()

    def update_patients_table(self):
        for row in self.patients_table.get_children():
            self.patients_table.delete(row)

        cursor.execute("SELECT FirstName, LastName, EmailID, ContactNumber FROM Patient")
        for row in cursor:
            self.patients_table.insert('', tk.END, values=row)

    def show_read_page(self):
        self.options_frame.pack_forget()
        self.read_frame.pack(fill="both", expand=True)

    def show_table(self):
        table_name = self.table_dropdown.get()
        if table_name:
            for row in self.table_content.get_children():
                self.table_content.delete(row)

            cursor.execute(f"SELECT * FROM [{table_name}]")
            columns = [desc[0] for desc in cursor.description]
            self.table_content['columns'] = columns
            self.table_content['show'] = 'headings'

            for col in columns:
                self.table_content.heading(col, text=col)

            for row in cursor:
                formatted_row = [str(value).translate(str.maketrans('', '', "[](),'\"")) for value in row]
                self.table_content.insert('', tk.END, values=formatted_row)

    def update_patient(self):
        self.options_frame.pack_forget()
        self.main_frame.pack(fill="both", expand=True)

        # Clear previous widgets in the main frame
        for widget in self.main_frame.winfo_children():
            widget.destroy()

        header_label = ctk.CTkLabel(self.main_frame, text="Update Data", font=("Arial", 24))
        header_label.pack(pady=20)

        # Table selection dropdown
        self.table_selection_update = ttk.Combobox(self.main_frame, state="readonly")
        self.table_selection_update.pack(pady=10)
        self.table_selection_update.bind("<<ComboboxSelected>>", self.generate_update_form_fields)

        # Fetch table names for the dropdown
        cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_type = 'BASE TABLE' AND table_schema = 'dbo'")
        self.table_selection_update['values'] = [row[0] for row in cursor.fetchall()]

        # Placeholder for update form fields
        self.update_form_frame = ctk.CTkFrame(self.main_frame)
        self.update_form_frame.pack(pady=10)

        back_button_update = ctk.CTkButton(self.main_frame, text="Back", command=self.show_options)
        back_button_update.pack(pady=10)

    def generate_update_form_fields(self, event):
        # Clear previous form fields
        for widget in self.update_form_frame.winfo_children():
            widget.destroy()

        table_name = self.table_selection_update.get()
        cursor.execute(f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{table_name}'")
        columns = [row[0] for row in cursor.fetchall()]

        self.checkboxes_update = {}
        for column in columns:
            var = tk.BooleanVar()
            chk = ctk.CTkCheckBox(self.update_form_frame, text=column, variable=var)
            chk.pack(side="top", anchor="w")
            self.checkboxes_update[column] = var

        # Primary key selection dropdown
        cursor.execute(f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_NAME = '{table_name}' AND OBJECTPROPERTY(OBJECT_ID(CONSTRAINT_SCHEMA + '.' + CONSTRAINT_NAME), 'IsPrimaryKey') = 1")

        primary_keys = [row[0] for row in cursor.fetchall()]
        self.primary_key_selection_update = ttk.Combobox(self.update_form_frame, values=primary_keys, state="readonly")
        self.primary_key_selection_update.pack(pady=10)
        self.primary_key_selection_update.bind("<<ComboboxSelected>>", self.prepare_update_form)

    def prepare_update_form(self, event):
        # Get the selected primary key
        primary_key = self.primary_key_selection_update.get()

        # Create a new frame for the update form
        self.update_data_frame = ctk.CTkFrame(self.main_frame)
        self.update_data_frame.pack(fill="both", expand=True)

        # Split the frame into two halves
        left_frame = ctk.CTkFrame(self.update_data_frame)
        left_frame.pack(side="left", fill="both", expand=True)
        right_frame = ctk.CTkFrame(self.update_data_frame)
        right_frame.pack(side="right", fill="both", expand=True)

        # Create entry for primary key value
        primary_key_value_frame = ctk.CTkFrame(left_frame)
        primary_key_value_frame.pack(fill="x", pady=5)
        primary_key_label = ctk.CTkLabel(primary_key_value_frame, text=primary_key)
        primary_key_label.pack(side="left", padx=5)
        primary_key_entry = ctk.CTkEntry(primary_key_value_frame)
        primary_key_entry.pack(side="right", padx=5)

        # Fetch button to load current data
        fetch_button = ctk.CTkButton(left_frame, text="Fetch Data", command=lambda: self.fetch_current_data(primary_key, primary_key_entry.get(), left_frame))
        fetch_button.pack(pady=10)

        # Placeholder for new data entries
        self.new_data_entries = {}

    def fetch_current_data(self, primary_key, primary_key_value, left_frame):
        # Clear previous data
        for widget in left_frame.winfo_children()[2:]:
            widget.destroy()

        # Fetch current data
        cursor.execute(f"SELECT * FROM {self.table_selection_update.get()} WHERE {primary_key} = ?", (primary_key_value,))
        current_data = cursor.fetchone()

        if current_data:
            for i, column in enumerate(self.checkboxes_update.keys()):
                if self.checkboxes_update[column].get():
                    label = ctk.CTkLabel(left_frame, text=f"{column}: {current_data[i]}")
                    label.pack(pady=5)

            # Populate the right side with entry fields for new data
            right_frame = self.update_data_frame.winfo_children()[1]
            for widget in right_frame.winfo_children():
                widget.destroy()

            for column in self.checkboxes_update.keys():
                if self.checkboxes_update[column].get():
                    frame = ctk.CTkFrame(right_frame)
                    frame.pack(fill="x", pady=5)
                    label = ctk.CTkLabel(frame, text=column)
                    label.pack(side="left", padx=5)
                    entry = ctk.CTkEntry(frame)
                    entry.pack(side="right", padx=5)
                    self.new_data_entries[column] = entry

            # Update button
            update_button = ctk.CTkButton(self.update_data_frame, text="Update", command=lambda: self.update_data(primary_key, primary_key_value))
            update_button.pack(pady=10)
        else:
            messagebox.showerror("Error", f"No record found with {primary_key} = {primary_key_value}")

    def update_data(self, primary_key, primary_key_value):
        # Construct the UPDATE SQL query
        table_name = self.table_selection_update.get()
        set_clause = ", ".join([f"{column} = '{self.new_data_entries[column].get()}'" for column in self.new_data_entries])
        where_clause = f"{primary_key} = '{primary_key_value}'"
        sql = f"UPDATE {table_name} SET {set_clause} WHERE {where_clause}"

        # Execute the query
        try:
            cursor.execute(sql)
            conn.commit()
            messagebox.showinfo("Success", "Record updated successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Could not update the record. {e}")

    def delete_patient(self):
        self.options_frame.pack_forget()
        self.main_frame.pack(fill="both", expand=True)

        # Clear previous widgets in the main frame
        for widget in self.main_frame.winfo_children():
            widget.destroy()

        header_label = ctk.CTkLabel(self.main_frame, text="Delete Data", font=("Arial", 24))
        header_label.pack(pady=20)

        # Table selection dropdown
        self.table_selection_delete = ttk.Combobox(self.main_frame, state="readonly")
        self.table_selection_delete.pack(pady=10)
        self.table_selection_delete.bind("<<ComboboxSelected>>", self.prepare_delete_options)

        # Fetch table names for the dropdown
        cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_type = 'BASE TABLE' AND table_schema = 'dbo'")
        self.table_selection_delete['values'] = [row[0] for row in cursor.fetchall()]

        # Placeholder for delete options
        self.delete_options_frame = ctk.CTkFrame(self.main_frame)
        self.delete_options_frame.pack(pady=10)

        back_button_delete = ctk.CTkButton(self.main_frame, text="Back", command=self.show_options)
        back_button_delete.pack(pady=10)

    def prepare_delete_options(self, event):
        # Clear previous options
        for widget in self.delete_options_frame.winfo_children():
            widget.destroy()

        delete_table_button = ctk.CTkButton(self.delete_options_frame, text="Delete Table", command=self.delete_table)
        delete_table_button.pack(pady=5)

        truncate_table_button = ctk.CTkButton(self.delete_options_frame, text="Truncate Table", command=self.truncate_table)
        truncate_table_button.pack(pady=5)

        delete_row_button = ctk.CTkButton(self.delete_options_frame, text="Delete a Row", command=self.delete_row)
        delete_row_button.pack(pady=5)

    def delete_table(self):
        table_name = self.table_selection_delete.get()
        if table_name:
            if messagebox.askyesno("Delete Table", f"Are you sure you want to delete the table '{table_name}'? This action cannot be undone."):
                try:
                    cursor.execute(f"DROP TABLE {table_name}")
                    conn.commit()
                    messagebox.showinfo("Success", f"Table '{table_name}' has been deleted.")
                    # Update the table selection dropdown
                    cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_type = 'BASE TABLE' AND table_schema = 'dbo'")
                    self.table_selection_delete['values'] = [row[0] for row in cursor.fetchall()]
                except Exception as e:
                    messagebox.showerror("Error", f"Could not delete the table. {e}")

    def truncate_table(self):
        table_name = self.table_selection_delete.get()
        if table_name:
            if messagebox.askyesno("Truncate Table", f"Are you sure you want to truncate the table '{table_name}'? This action cannot be undone."):
                try:
                    cursor.execute(f"TRUNCATE TABLE {table_name}")
                    conn.commit()
                    messagebox.showinfo("Success", f"Table '{table_name}' has been truncated.")
                except Exception as e:
                    messagebox.showerror("Error", f"Could not truncate the table. {e}")

    def delete_row(self):
        self.delete_options_frame.pack_forget()
        self.delete_row_frame = ctk.CTkFrame(self.main_frame)
        self.delete_row_frame.pack(fill="both", expand=True)

        table_name = self.table_selection_delete.get()
        cursor.execute(f"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{table_name}'")
        columns = [row[0] for row in cursor.fetchall()]

        # Column selection dropdown
        self.column_selection_delete = ttk.Combobox(self.delete_row_frame, values=columns, state="readonly")
        self.column_selection_delete.pack(pady=10)

        # Column value entry
        self.column_value_delete = ctk.CTkEntry(self.delete_row_frame)
        self.column_value_delete.pack(pady=10)

        # Delete button
        delete_button = ctk.CTkButton(self.delete_row_frame, text="Delete Row", command=self.execute_delete_row)
        delete_button.pack(pady=10)

        back_button_delete_row = ctk.CTkButton(self.delete_row_frame, text="Back", command=lambda: self.delete_row_frame.pack_forget() or self.delete_options_frame.pack(pady=10))
        back_button_delete_row.pack(pady=10)

    def execute_delete_row(self):
        table_name = self.table_selection_delete.get()
        column = self.column_selection_delete.get()
        column_value = self.column_value_delete.get()

        if table_name and column and column_value:
            if messagebox.askyesno("Delete Row", f"Are you sure you want to delete the row with {column} = '{column_value}' from the table '{table_name}'? This action cannot be undone."):
                try:
                    cursor.execute(f"DELETE FROM {table_name} WHERE {column} = ?", (column_value,))
                    conn.commit()
                    messagebox.showinfo("Success", f"Row with {column} = '{column_value}' has been deleted from the table '{table_name}'.")
                except Exception as e:
                    messagebox.showerror("Error", f"Could not delete the row. {e}")

    def read_patient(self):
        # Placeholder for read functionality
        print("Read patient")

    def view_patient(self):
        # Placeholder for views functionality
        print("View patient")

    def stored_procedure(self):
        # Placeholder for stored procedure functionality
        print("Stored procedure")

if __name__ == "__main__":
    root = tk.Tk()
    app = CustomApp(root)
    root.mainloop()
